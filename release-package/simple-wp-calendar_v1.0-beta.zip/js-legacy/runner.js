"use strict";

swpCal.anchorMiniCal = document.getElementById("swp-cal-mini-main");
swpCal.anchorList = document.getElementById("swp-cal-list-main");
swpCal.run();